// Field Availability Data
// Each field has a status (available/occupied/reserved) and surface type
const fieldData = [
    {
        name: "Gesling Stadium",
        status: "available",
        surface: "Turf",
        hours: "6 AM - 10 PM",
        features: "Track, bleachers, lights"
    },
    {
        name: "The Cut",
        status: "occupied",
        surface: "Grass",
        hours: "Dawn - Dusk",
        features: "Open field, frisbee-friendly"
    },
    {
        name: "CFA Lawn",
        status: "available",
        surface: "Grass",
        hours: "Dawn - Dusk",
        features: "Casual games, events"
    },
    {
        name: "Wiegand Gym Courts",
        status: "reserved",
        surface: "Indoor Court",
        hours: "6 AM - 11 PM",
        features: "Basketball, volleyball"
    }
];